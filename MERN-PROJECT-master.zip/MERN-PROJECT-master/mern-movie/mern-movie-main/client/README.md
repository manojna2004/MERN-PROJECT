# BertFlix (MERN-MOVIE)

Fronted (Client)